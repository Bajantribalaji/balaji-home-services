/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.dev/license
 */
import { RuleFactory } from '@angular-devkit/schematics';
import { Schema as ServiceOptions } from './schema';
declare const serviceSchematic: RuleFactory<ServiceOptions>;
export default serviceSchematic;
